#pragma once
class MyBase
{
};

